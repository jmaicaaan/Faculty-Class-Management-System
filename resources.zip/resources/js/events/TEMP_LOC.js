﻿(function () {
    angular.module("events")
        .constant("TEMP_LOC", {
            PATH: "resources/templates/"
        });
})();