(function(){
	angular.module("attendanceModule")
		.controller("recordAttendanceCtrl", recordAttendanceCtrl);

	function recordAttendanceCtrl(){
		var self = this;
	}
})();