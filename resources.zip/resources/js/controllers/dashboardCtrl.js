(function(){
	angular.module("facultyApp")
		.controller("dashboardCtrl", dashboardCtrl);

	function dashboardCtrl($state, $scope, userObj, userService, stateService){
		var self = this;
		self.user = userObj;
		self.currentState = {};
		self.userRole = userService.userInfo.userRole;


		getAccountType();

		$scope.$watch(function () {
		    return stateService.currentState;
		}, function (newValue) {
		    console.log(newValue);
		    self.currentState = newValue;
		});
        
		function getAccountType() {
			var ac = self.userRole;
			self.hasAuth = (ac == 'Student' || ac == 'Developer') ? true : false;
		}
	}
}());